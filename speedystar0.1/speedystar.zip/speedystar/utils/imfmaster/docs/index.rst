Documentation
=============

This package is very shy on documentation at the moment.  There's a nice set of examples here:
https://github.com/keflavich/imf/tree/master/examples

but almost nothing else has been documented.

Advanced
^^^^^^^^

.. toctree::
   :maxdepth: 1
