from mwdust import download_all

def test_download():
    download_all(test=True)
    return None
